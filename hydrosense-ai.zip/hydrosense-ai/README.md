# HydroSense AI
React + TypeScript + Vite web app (installable on phones as a web app). Live dashboard, risk engine with explanations, hydration advice, HYDRO AI (rule-based), history, profile, simulated sensor mode, Web Bluetooth.

## Deploy on GitHub
1. Create a repo, upload these files (unzipped) to `main`.
2. Settings → Pages → Source: **GitHub Actions**. Push; the workflow builds and publishes.
## Run locally
`npm install && npm run dev`

## New in v0.2
Splash, onboarding redirect, voice/vibration alerts with custom thresholds, GPS distance, team monitor, weekly/monthly/yearly reports, calibration + signal quality, offline PWA, cloud-sync queue, FastAPI + Postgres + Redis backend (`docker compose up`, API on :8000), per-user ML insights (scikit-learn, real sessions only), Android APK workflow.

## Backend
`docker compose up --build`, then in the app: Device tab -> set Backend URL (http://HOST:8000) -> Register/Log in -> Sync. Set a strong `JWT_SECRET` and `CORS_ORIGINS`; use HTTPS in production (GitHub Pages is HTTPS, so the API must be too).

## Android / iOS
Actions tab -> "Android debug APK" -> Run workflow -> download the APK artifact (Capacitor wrapper; untested). iOS: `npx cap add ios` on a Mac. Note: Web Bluetooth does not work in the Android WebView; native BLE needs `@capacitor-community/bluetooth-le`.

## Honest scope
- Simulated data is labeled and is not measurement. Real sweat sensors need your hardware's GATT UUIDs mapped into `Reading` (src/engine.ts).
- Not done: native React Native rewrite, smartwatch apps, live team data over WebSocket in the UI, ML model trained on real validated data, laboratory validation, true PDF generation (print-to-PDF), firmware OTA.
- Sodium loss = sweat rate x sweat [Na+] x 22.99. Risk levels are heuristic, not diagnostic.

## v0.3 additions
- **Real sensor decoding:** `src/sensorProfile.ts` defines the GATT UUIDs and an 18-byte CRC8-protected frame (corrupt frames dropped, invalid channels = null). The UUIDs/layout are placeholders: change them to match your hardware, or make your firmware emit this format.
- **Bluetooth in Android:** `src/ble.ts` uses Capacitor BLE natively and Web Bluetooth in Chrome. The Android workflow adds the permissions.
- **React Native (Expo):** `mobile/` app with native BLE. `cd mobile && npm install && npx expo prebuild && npx expo run:android` (needs a dev build, not Expo Go). `mobile/src/engine.ts` and `sensorProfile.ts` are copies; keep them in sync.
- **Smartwatch:** open `#watch` (e.g. `https://you.github.io/repo/#watch`) for a glanceable view. Native Wear OS / watchOS apps are NOT included.
- **Live team:** Team tab, same room name for athletes and coach; backend + login required.
- **PDF:** real PDF via jsPDF. **Firmware:** chunked CRC32 upload per the protocol in `src/firmware.ts` (your firmware must implement it).
- **Lab validation:** Device tab -> paired sensor/lab entries -> bias, MAPE, correlation, limits of agreement, suggested calibration factor. This is the tool; the validation itself needs your lab data.
