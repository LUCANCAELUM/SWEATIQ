import os, time, hashlib, secrets, jwt
from typing import List
from fastapi import FastAPI, Depends, HTTPException, Header, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from sqlalchemy import create_engine, Column, Integer, String, Float, Boolean
from sqlalchemy.orm import declarative_base, sessionmaker, Session
from ml import insights

SECRET = os.getenv("JWT_SECRET", "change-me")
engine = create_engine(os.getenv("DATABASE_URL", "sqlite:///hs.db"))
SL = sessionmaker(bind=engine); Base = declarative_base()
try:
    import redis; R = redis.from_url(os.environ["REDIS_URL"])
except Exception: R = None

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True); email = Column(String, unique=True); name = Column(String)
    salt = Column(String); pw = Column(String)
class Workout(Base):
    __tablename__ = "workouts"
    id = Column(Integer, primary_key=True); user_id = Column(Integer, index=True); date = Column(String)
    dur = Column(Float); loss = Column(Float); intake = Column(Float); na_mg = Column(Float); risk = Column(String); sim = Column(Boolean)
Base.metadata.create_all(engine)

app = FastAPI(title="HydroSense API")
app.add_middleware(CORSMiddleware, allow_origins=os.getenv("CORS_ORIGINS", "*").split(","), allow_methods=["*"], allow_headers=["*"])
def db():
    s = SL()
    try: yield s
    finally: s.close()
def hp(pw, salt): return hashlib.pbkdf2_hmac("sha256", pw.encode(), salt.encode(), 200_000).hex()
def token(uid): return jwt.encode({"sub": str(uid), "exp": int(time.time()) + 30*86400}, SECRET, algorithm="HS256")
def uid_of(t):
    try: return int(jwt.decode(t, SECRET, algorithms=["HS256"])["sub"])
    except Exception: raise HTTPException(401, "Invalid token")
def me(authorization: str = Header("")): return uid_of(authorization.removeprefix("Bearer "))

class Cred(BaseModel): email: str; password: str; name: str = ""
class W(BaseModel): date: str; dur: float; loss: float; intake: float; naMg: float; risk: str; sim: bool = False

@app.post("/auth/register")
def register(c: Cred, s: Session = Depends(db)):
    if len(c.password) < 6 or s.query(User).filter_by(email=c.email).first(): raise HTTPException(400, "Invalid or existing account")
    salt = secrets.token_hex(8); u = User(email=c.email, name=c.name, salt=salt, pw=hp(c.password, salt)); s.add(u); s.commit()
    return {"token": token(u.id)}
@app.post("/auth/login")
def login(c: Cred, s: Session = Depends(db)):
    u = s.query(User).filter_by(email=c.email).first()
    if not u or u.pw != hp(c.password, u.salt): raise HTTPException(401, "Wrong email or password")
    return {"token": token(u.id)}
@app.post("/sessions/bulk")
def bulk(ws: List[W], uid: int = Depends(me), s: Session = Depends(db)):
    for w in ws: s.add(Workout(user_id=uid, date=w.date, dur=w.dur, loss=w.loss, intake=w.intake, na_mg=w.naMg, risk=w.risk, sim=w.sim))
    s.commit(); return {"saved": len(ws)}
@app.get("/sessions")
def sessions(uid: int = Depends(me), s: Session = Depends(db)):
    return [dict(date=w.date, dur=w.dur, loss=w.loss, intake=w.intake, naMg=w.na_mg, risk=w.risk, sim=w.sim) for w in s.query(Workout).filter_by(user_id=uid).order_by(Workout.id.desc())]
@app.get("/insights")
def ins(planned_min: float = 60, uid: int = Depends(me), s: Session = Depends(db)):
    return insights(s.query(Workout).filter_by(user_id=uid).all(), planned_min)

rooms: dict = {}
@app.websocket("/ws/{room}")
async def ws(sock: WebSocket, room: str, token: str):
    uid = uid_of(token); await sock.accept(); rooms.setdefault(room, set()).add(sock)
    try:
        while True:
            m = await sock.receive_text()
            if R: R.setex(f"latest:{room}:{uid}", 30, m)
            for c in list(rooms[room]):
                if c is not sock: await c.send_text(m)
    except WebSocketDisconnect: rooms[room].discard(sock)
