import numpy as np
from sklearn.linear_model import LinearRegression
def insights(rows, planned_min):
    rows=[r for r in rows if not r.sim]  # never learn from simulated data
    if not rows: return {"n":0,"note":"No real sessions yet."}
    dur=np.array([[r.dur/60] for r in rows]); loss=np.array([r.loss for r in rows]); na=np.array([r.na_mg for r in rows])
    h=dur.sum()/60
    out={"n":len(rows),"avg_loss_ml_per_h":round(float(loss.sum()/h)) if h else 0,"avg_sodium_mg_per_h":round(float(na.sum()/h)) if h else 0}
    out["predicted_loss_ml"]=round(float(LinearRegression().fit(dur,loss).predict([[planned_min]])[0])) if len(rows)>=3 else round(out["avg_loss_ml_per_h"]*planned_min/60)
    out["note"]="Statistical estimate from your own sessions; not clinically validated."
    return out
