import React,{useRef,useState} from 'react'
import {View,Text,Button,ScrollView,PermissionsAndroid,Platform} from 'react-native'
import {BleManager} from 'react-native-ble-plx'
import {Buffer} from 'buffer'
import {PROFILE,decodeSweat} from './src/sensorProfile'
import {assess,sodiumMgH,recommend} from './src/engine'
const mgr=new BleManager(),prof:any={name:'Athlete',age:30,mass:70,sport:'',level:''}
const COL:any={GREEN:'#39ff88',YELLOW:'#ffd23f',ORANGE:'#ff8a2b',RED:'#ff3b4e'}
export default function App(){
  const [r,setR]=useState<any>(null),[st,setSt]=useState('Not connected'),[intake,setIntake]=useState(0)
  const loss=useRef(0),last=useRef(0),t0=useRef(0)
  const connect=async()=>{
    if(Platform.OS==='android'){const P=PermissionsAndroid.PERMISSIONS;await PermissionsAndroid.requestMultiple([P.BLUETOOTH_SCAN,P.BLUETOOTH_CONNECT,P.ACCESS_FINE_LOCATION])}
    setSt('Scanning…')
    mgr.startDeviceScan([PROFILE.service],null,async(e,d)=>{
      if(e){setSt(e.message);return}if(!d)return;mgr.stopDeviceScan()
      try{const c=await d.connect();await c.discoverAllServicesAndCharacteristics();setSt('Connected: '+(d.name||d.id));t0.current=Date.now();last.current=0;loss.current=0
        c.onDisconnected(()=>setSt('Sensor connection interrupted'))
        c.monitorCharacteristicForService(PROFILE.service,PROFILE.data,(er,ch)=>{if(er||!ch?.value)return
          const s=decodeSweat(new Uint8Array(Buffer.from(ch.value,'base64')));if(!s)return;const now=Date.now()
          if(s.rate!=null&&last.current)loss.current+=s.rate*(now-last.current)/3.6e6;last.current=now
          setR({t:(now-t0.current)/1000,...s,hr:null,env:null,hum:null,speed:null,loss:loss.current,sim:false})})}catch(x:any){setSt('Failed: '+x.message)}})}
  const A=r?assess(r,intake,prof):null,na=r?sodiumMgH(r):null,f=(v:any,u:string)=>v==null?'—':Math.round(v*10)/10+u
  return<ScrollView style={{flex:1,backgroundColor:'#03070d'}} contentContainerStyle={{padding:20,paddingTop:60}}>
    <Text style={{color:'#19e3ff',fontSize:20,fontWeight:'700'}}>HYDROSENSE AI</Text><Text style={{color:'#8fb3c7'}}>{st}</Text>
    <Button title="Connect sweat sensor" onPress={connect}/><Button title="+100 mL drank" onPress={()=>setIntake(i=>i+100)}/>
    {A&&<Text style={{color:COL[A.level],fontSize:28,marginVertical:12}}>{A.level}</Text>}
    {r&&<View>{[['Sweat rate',f(r.rate,' mL/h')],['Total loss (calc)',f(r.loss,' mL')],['Sweat Na',f(r.na,' mmol/L')],['Na loss (calc)',f(na,' mg/h')],['K',f(r.k,' mmol/L')],['Cl',f(r.cl,' mmol/L')],['pH',f(r.ph,'')],['Skin',f(r.skin,' °C')],['Battery',r.battery+'%']].map(([k,v])=><Text key={k} style={{color:'#e6f6ff',fontSize:16,marginVertical:3}}>{k}: {v}</Text>)}
      <Text style={{color:'#e6f6ff',marginTop:12}}>{recommend(r,intake,prof)}</Text></View>}
  </ScrollView>}
