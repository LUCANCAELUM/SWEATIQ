export type Reading={t:number;rate:number|null;na:number|null;k:number|null;cl:number|null;ph:number|null;skin:number|null;hr:number|null;env:number;hum:number;speed:number;loss:number;sim:boolean}
export type Prof={name:string;age:number;mass:number;sport:string;level:string}
export type Level='GREEN'|'YELLOW'|'ORANGE'|'RED'
const j=(a:number,s:number)=>a+(Math.random()-.5)*s
export const NA_MG_PER_MMOL=22.99
// Calculated estimate: sodium loss (mg/h) = sweat rate (L/h) x sweat [Na+] (mmol/L) x 22.99
export const sodiumMgH=(r:Reading)=>r.rate!=null&&r.na!=null?(r.rate/1000)*r.na*NA_MG_PER_MMOL:null
// SIMULATED device: generates synthetic data for demos only. Never real measurements.
export function simulate(t:number,prev:Reading|null,dt:number):Reading{
  const m=t/60,rate=Math.max(0,j(620+m*4.5,60)),loss=(prev?.loss||0)+rate*dt/3600
  return{t,rate,na:j(42+m*.08,4),k:j(5,.6),cl:j(36,4),ph:j(6.1,.2),skin:j(33+Math.min(m/60*3,4),.2),
    hr:j(135+Math.min(m*.35,35),4),env:j(30,.4),hum:j(62,2),speed:j(2.9,.2),loss,sim:true}
}
export function assess(r:Reading,intake:number,p:Prof){
  const deficit=Math.max(0,r.loss-intake),pct=deficit/(p.mass*10),f:string[]=[];let s=0
  const add=(n:number,x:string)=>{s+=n;f.push(`${x} (+${n})`)}
  if(pct>=2)add(3,`Estimated deficit ${pct.toFixed(1)}% of body mass`);else if(pct>=1.5)add(2,`Estimated deficit ${pct.toFixed(1)}% of body mass`);else if(pct>=1)add(1,`Estimated deficit ${pct.toFixed(1)}% of body mass`)
  if(r.skin!=null){if(r.skin>=37.5)add(2,`Skin temp ${r.skin.toFixed(1)}°C`);else if(r.skin>=36.5)add(1,`Skin temp ${r.skin.toFixed(1)}°C`)}
  if(r.hr!=null){const x=r.hr/(220-p.age);if(x>=.95)add(2,`HR at ${Math.round(x*100)}% of age-predicted max`);else if(x>=.85)add(1,`HR at ${Math.round(x*100)}% of age-predicted max`)}
  if(r.env>=32)add(2,`Heat stress: ${r.env.toFixed(0)}°C`);else if(r.env>=27)add(1,`Warm conditions: ${r.env.toFixed(0)}°C`)
  if(r.rate!=null&&r.rate>1500)add(1,`High sweat rate ${Math.round(r.rate)} mL/h`)
  if(r.t>5400)add(1,'Long duration (>90 min)')
  const level:Level=s>=6?'RED':s>=4?'ORANGE':s>=2?'YELLOW':'GREEN'
  return{level,score:s,factors:f,deficit,pct}
}
export function recommend(r:Reading|null,intake:number,p:Prof){
  if(!r||r.rate==null)return'No sweat-sensor data yet. Connect a compatible sweat device or start simulated mode.'
  const a=assess(r,intake,p)
  if(a.level==='RED')return'Stop exercising, move to shade, cool down and get help. Seek immediate medical attention for confusion, vomiting, fainting or headache with heat symptoms.'
  if(a.deficit<150)return'Estimated fluid balance is close to your losses. No extra drinking needed beyond thirst.'
  const v=Math.min(250,Math.max(100,Math.round(a.deficit*.4/50)*50))
  return`Estimated unreplaced loss: ${Math.round(a.deficit)} mL. Consider about ${v} mL over the next 15–20 min. Do not drink beyond your losses (risk of exercise-associated hyponatremia). Adjust to your personal plan.`
}
export function ask(q:string,r:Reading|null,intake:number,p:Prof,hist:any[]){
  const s=q.toLowerCase();if(!r)return'Start a session first, then ask me about your live data.'
  const na=sodiumMgH(r)
  if(/sodium|salt/.test(s))return na==null?'No sodium data available.':`Estimated sodium loss rate: ${Math.round(na)} mg/h (calculated from sweat rate × measured sweat [Na+] of ${r.na.toFixed(0)} mmol/L). Sweat sodium is not blood sodium.`
  if(/fluid|losing|sweat/.test(s))return`Sweat rate is ${Math.round(r.rate??0)} mL/h. Estimated total loss ${Math.round(r.loss)} mL; intake logged ${Math.round(intake)} mL.`
  if(/21|race|hot|prepare/.test(s))return'General guidance: complete a sweat test in similar heat, rehearse your drinking plan in training, start hydrated, and replace only a portion of losses. Plan electrolytes using your measured sodium loss rate. Consult a sports dietitian for race-day targets.'
  if(/previous|compare|history/.test(s))return hist.length?`Last session: ${Math.round(hist[0].loss)} mL estimated loss over ${Math.round(hist[0].dur/60)} min.`:'No saved sessions yet to compare.'
  return'I can discuss fluid loss, sodium loss, race prep and session comparisons. (Rule-based assistant, not a medical advisor.)'
}
