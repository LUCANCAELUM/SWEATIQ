// EDIT THESE UUIDs to match your hardware. Frame layout (18 bytes, little-endian):
// 0 ver(=1) | 1 flags(b0 sensor ok,b2 wet,b3 low batt) | 2-3 seq | 4-5 rate 0.1mL/h | 6-7 Na 0.1mmol/L | 8-9 K | 10-11 Cl | 12-13 pH 0.01 | 14-15 skin i16 0.01C | 16 battery% | 17 CRC8(poly 0x07) over 0..16. 0xFFFF = invalid.
export const PROFILE={service:'0000aa00-0000-1000-8000-00805f9b34fb',data:'0000aa01-0000-1000-8000-00805f9b34fb',fwControl:'0000aa10-0000-1000-8000-00805f9b34fb',fwData:'0000aa11-0000-1000-8000-00805f9b34fb',hrService:'0000180d-0000-1000-8000-00805f9b34fb',hrChar:'00002a37-0000-1000-8000-00805f9b34fb'}
export type Sample={seq:number;ok:boolean;wet:boolean;lowBatt:boolean;battery:number;rate:number|null;na:number|null;k:number|null;cl:number|null;ph:number|null;skin:number|null}
export function crc8(b:Uint8Array){let c=0;for(const x of b){c^=x;for(let i=0;i<8;i++)c=c&0x80?((c<<1)^0x07)&0xff:(c<<1)&0xff}return c}
// Returns null for corrupt frames; invalid/unready channels become null (never fabricated).
export function decodeSweat(b:Uint8Array):Sample|null{
  if(b.length!==18||b[0]!==1||crc8(b.subarray(0,17))!==b[17])return null
  const v=new DataView(b.buffer,b.byteOffset,b.byteLength),ok=!!(b[1]&1)
  const u=(o:number,s:number)=>{const x=v.getUint16(o,true);return ok&&x!==0xffff?x*s:null}
  const sk=v.getInt16(14,true)
  return{seq:v.getUint16(2,true),ok,wet:!!(b[1]&4),lowBatt:!!(b[1]&8),battery:b[16],rate:u(4,.1),na:u(6,.1),k:u(8,.1),cl:u(10,.1),ph:u(12,.01),skin:ok&&sk!==-32768?sk*.01:null}}
