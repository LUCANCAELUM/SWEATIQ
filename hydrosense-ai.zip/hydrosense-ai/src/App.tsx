import {useEffect,useRef,useState} from 'react'
import {Reading,Prof,simulate,sodiumMgH,assess,recommend,ask} from './engine'
import {Splash as _S,Th,DEF_TH,useAlerts,useGps,Team,Reports,DevicePanel,Validation,usePublish} from './extras'
import {enqueue} from './api'
import {connectSensor} from './ble'
const ls=<T,>(k:string,d:T):T=>{try{return JSON.parse(localStorage.getItem(k)||'')??d}catch{return d}}
const save=(k:string,v:any)=>localStorage.setItem(k,JSON.stringify(v))
const COL:any={GREEN:'#39ff88',YELLOW:'#ffd23f',ORANGE:'#ff8a2b',RED:'#ff3b4e'}
const SIM_DT=10 // simulated seconds per real second
const Spark=({d,c='#19e3ff'}:{d:number[];c?:string})=>{
  if(d.length<2)return<svg className="sp"/>;const mx=Math.max(...d),mn=Math.min(...d),r=mx-mn||1
  return<svg className="sp" viewBox="0 0 100 30" preserveAspectRatio="none"><polyline fill="none" stroke={c} strokeWidth="1.5" points={d.map((v,i)=>`${i/(d.length-1)*100},${28-(v-mn)/r*26}`).join(' ')}/></svg>}
const Tile=({l,v,u,k,h,c}:{l:string;v:any;u:string;k:'measured'|'calculated'|'sim';h?:number[];c?:string})=>
  <div className="tile"><div className="tl">{l}<i className={k}>{k==='sim'?'simulated':k}</i></div><b>{v??'—'}<small>{u}</small></b>{h&&<Spark d={h} c={c}/>}</div>
function Auth({onOk}:{onOk:(u:any)=>void}){
  const [reg,setReg]=useState(false),[f,setF]=useState({name:'',email:'',pw:''}),[e,setE]=useState('')
  const go=()=>{const users=ls<any[]>('hs_users',[]);const u=users.find(x=>x.email===f.email)
    if(reg){if(!f.email||f.pw.length<6)return setE('Enter an email and a password of 6+ characters.');if(u)return setE('Account exists. Log in instead.')
      const n={...f};save('hs_users',[...users,n]);onOk(n)}else{if(!u||u.pw!==f.pw)return setE('Wrong email or password.');onOk(u)}}
  return<div className="auth"><h1>HYDROSENSE <span>AI</span></h1><p>Sweat-science hydration for endurance athletes.</p>
    {reg&&<input placeholder="Name" value={f.name} onChange={x=>setF({...f,name:x.target.value})}/>}
    <input placeholder="Email" value={f.email} onChange={x=>setF({...f,email:x.target.value})}/>
    <input placeholder="Password" type="password" value={f.pw} onChange={x=>setF({...f,pw:x.target.value})}/>
    {e&&<div className="err">{e}</div>}<button onClick={go}>{reg?'Create account':'Log in'}</button>
    <a onClick={()=>setReg(!reg)}>{reg?'I have an account':'Create an account'}</a>
    <small>Demo auth: accounts are stored on this device only. Add the FastAPI backend for real accounts.</small></div>}
export default function App(){
  const [user,setUser]=useState<any>(ls('hs_user',null)),[tab,setTab]=useState('live')
  const [prof,setProf]=useState<Prof>(ls('hs_prof',{name:'',age:30,mass:70,sport:'Running',level:'Intermediate'}))
  const [run,setRun]=useState(false),[mode,setMode]=useState<'sim'|'ble'>('sim'),[rd,setRd]=useState<Reading[]>([])
  const [intake,setIntake]=useState(0),[hist,setHist]=useState<any[]>(ls('hs_hist',[])),[hr,setHr]=useState<number|null>(null)
  const [dev,setDev]=useState('Not connected'),[chat,setChat]=useState<string[]>([]),[q,setQ]=useState(''),[maxL,setMaxL]=useState(0)
  const rr=useRef<Reading|null>(null);const t=useRef(0)
  const [th,setTh]=useState<Th>(ls('hs_th',DEF_TH)),[cal,setCal]=useState<number>(ls('hs_cal',1));const calR=useRef(cal);calR.current=cal;const gps=useGps(run);const startMs=useRef(0),runR=useRef(false),hrR=useRef<number|null>(null),bh=useRef<any>(null);runR.current=run
  useEffect(()=>{if(!run||mode!=='sim')return;const id=setInterval(()=>{t.current+=SIM_DT;const r=simulate(t.current,rr.current,SIM_DT);r.na*=calR.current;rr.current=r;setRd(a=>[...a.slice(-119),r])},1000);return()=>clearInterval(id)},[run,mode])
  const cur=rd[rd.length-1]||null;const A=cur?assess(cur,intake,prof):null;const alert=useAlerts(A,cur,th,intake);usePublish(cur,A,prof.name,intake)
  useEffect(()=>{if(A)setMaxL(m=>Math.max(m,['GREEN','YELLOW','ORANGE','RED'].indexOf(A.level)))},[A?.level])
  const start=()=>{startMs.current=Date.now();t.current=0;rr.current=null;setRd([]);setIntake(0);setMaxL(0);setRun(true)}
  const stop=()=>{setRun(false);if(cur){const h=[{date:new Date().toISOString(),dur:cur.t,loss:cur.loss,intake,naMg:(sodiumMgH(cur)||0)*cur.t/3600,risk:['GREEN','YELLOW','ORANGE','RED'][maxL],sim:cur.sim},...hist];setHist(h);save('hs_hist',h);enqueue(h[0])}}
  const ble=async()=>{try{let ts=0;bh.current=await connectSensor({
    onSample:s=>{setDev(`Sensor connected · battery ${s.battery}%${s.ok?'':' · sensor not ready'}`);if(!runR.current)return;const now=Date.now();let ls=rr.current?.loss||0;if(s.rate!=null&&ts&&rr.current)ls+=s.rate*(now-ts)/3.6e6;ts=now;t.current=(now-startMs.current)/1000
      const r:any={t:t.current,rate:s.rate,na:s.na!=null?s.na*calR.current:null,k:s.k,cl:s.cl,ph:s.ph,skin:s.skin,hr:hrR.current,env:null,hum:null,speed:null,loss:ls,sim:false};rr.current=r;setRd(a=>[...a.slice(-119),r])},
    onHr:b=>{hrR.current=b;setHr(b)},onState:x=>setDev(x)});setMode('ble')}catch(e:any){setDev('Failed: '+(e.message||e))}}
  if(user&&location.hash==='#watch')return<div className="watch" style={{color:A?COL[A.level]:'#8fb3c7'}}><b>{A?.level||'IDLE'}</b><div>{cur?Math.round(cur.loss)+' mL lost':'Start on phone'}</div><div>{cur?.rate?Math.round(cur.rate)+' mL/h':''}</div><button onClick={()=>setIntake(i=>i+100)}>+100 mL</button></div>
  if(!user)return<Auth onOk={u=>{save('hs_user',u);setUser(u);setProf(p=>({...p,name:u.name}));setTab('profile')}}/>
  const h=(k:string)=>rd.map((r:any)=>r[k]).filter(v=>v!=null)
  const k=cur?.sim?'sim':'measured',na=cur?sodiumMgH(cur):null
  return<div className="app"><header><b>HYDROSENSE <span>AI</span></b><em>{mode==='sim'?'SIMULATED DEVICE – not real measurements':'BLE: '+dev}</em></header>
  <main>
  {tab==='live'&&<>
    <div className="ctl">{!run?<button onClick={start}>Start session</button>:<button className="stop" onClick={stop}>Stop & save</button>}
      <button className="alt" onClick={()=>setIntake(i=>i+100)} disabled={!run}>+100 mL drank</button></div>
    {alert&&<div className={'alert '+(alert.u?'urgent':'')}>{alert.u?'URGENT: ':'Reminder: '}{alert.t}</div>}
    {A&&<div className="risk" style={{borderColor:COL[A.level]}}><div className="ring" style={{background:`conic-gradient(${COL[A.level]} ${A.score*12}%,#12202e 0)`}}><span style={{color:COL[A.level]}}>{A.level}</span></div>
      <div><b>Hydration risk <i className="sim">AI estimate</i></b><ul>{A.factors.length?A.factors.map(x=><li key={x}>{x}</li>):<li>No elevated factors</li>}</ul><small>Not a diagnosis. Stop and seek help for dizziness, confusion or nausea.</small></div></div>}
    {!cur&&<p className="empty">Press Start session. Simulated mode generates demo data; connect real hardware under Device.</p>}
    {cur&&<div className="grid">
      <Tile l="Sweat rate" v={cur.rate&&Math.round(cur.rate)} u=" mL/h" k={k} h={h('rate')}/>
      <Tile l="Total sweat loss" v={Math.round(cur.loss)} u=" mL" k="calculated" h={h('loss')} c="#39ff88"/>
      <Tile l="Sweat sodium" v={cur.na&&cur.na.toFixed(0)} u=" mmol/L" k={k} h={h('na')}/>
      <Tile l="Sodium loss" v={na&&Math.round(na)} u=" mg/h" k="calculated"/>
      <Tile l="Potassium" v={cur.k&&cur.k.toFixed(1)} u=" mmol/L" k={k}/><Tile l="Chloride" v={cur.cl&&cur.cl.toFixed(0)} u=" mmol/L" k={k}/>
      <Tile l="Sweat pH" v={cur.ph&&cur.ph.toFixed(1)} u="" k={k}/><Tile l="Skin temp" v={cur.skin&&cur.skin.toFixed(1)} u=" °C" k={k} h={h('skin')}/>
      <Tile l="Heart rate" v={hr??(cur.hr&&Math.round(cur.hr))} u=" bpm" k={hr?'measured':k} h={h('hr')}/>
      <Tile l="Speed / dist" v={cur.speed!=null?`${(cur.speed*3.6).toFixed(1)} km/h · ${(cur.speed*cur.t/1000).toFixed(1)} km`:null} u="" k={k}/>
      <Tile l="Ambient" v={cur.env!=null?`${cur.env.toFixed(0)}°C · ${cur.hum.toFixed(0)}%`:null} u="" k={k}/>
      <Tile l="GPS distance" v={(gps/1000).toFixed(2)} u=" km" k="measured"/><Tile l="Fluid intake" v={intake} u=" mL" k="measured"/></div>}</>}
  {tab==='hydration'&&<div className="card"><h2>Hydration recommendation</h2><p>{recommend(cur,intake,prof)}</p>
    <small>Estimates only. Recommendations never exceed estimated losses. Personalise with a lab sweat test and a sports dietitian.</small></div>}
  {tab==='ai'&&<div className="card"><h2>HYDRO AI</h2><small>Rule-based demo assistant using your session data. Connect an LLM backend for open-ended answers.</small>
    {chat.map((m,i)=><p key={i} className={i%2?'bot':'me'}>{m}</p>)}
    <div className="ctl"><input value={q} placeholder="How much sodium am I losing?" onChange={e=>setQ(e.target.value)}/>
    <button onClick={()=>{if(q){setChat([...chat,q,ask(q,cur,intake,prof,hist)]);setQ('')}}}>Ask</button></div></div>}
  {tab==='history'&&<div className="card"><h2>Workout history</h2>{!hist.length&&<p>No saved sessions yet.</p>}
    {hist.map((s,i)=><div key={i} className="row"><b>{new Date(s.date).toLocaleString()}</b>{s.sim&&<i className="sim">simulated</i>}
    <span>{Math.round(s.dur/60)} min · loss {Math.round(s.loss)} mL · drank {Math.round(s.intake)} mL · Na {Math.round(s.naMg)} mg · peak {s.risk}</span></div>)}
    {!!hist.length&&<button className="alt" onClick={()=>window.print()}>Print / save PDF</button>}</div>}
  {tab==='profile'&&<div className="card"><h2>Athlete profile</h2>
    {(['name','sport','level'] as const).map(x=><label key={x}>{x}<input value={prof[x]} onChange={e=>{const p={...prof,[x]:e.target.value};setProf(p);save('hs_prof',p)}}/></label>)}
    {(['age','mass'] as const).map(x=><label key={x}>{x==='mass'?'body mass (kg)':x}<input type="number" value={prof[x]} onChange={e=>{const p={...prof,[x]:+e.target.value};setProf(p);save('hs_prof',p)}}/></label>)}
    <h2>Device</h2><p>{dev}</p><div className="ctl"><button onClick={()=>setMode('sim')}>Use simulator</button><button className="alt" onClick={ble}>Connect Bluetooth</button></div>
    <small>Connects to a sensor using the GATT profile in src/sensorProfile.ts (edit UUIDs for your hardware).</small>
    <button className="alt" onClick={()=>{localStorage.removeItem('hs_user');setUser(null)}}>Log out</button></div>}
  {tab==='team'&&<Team/>}{tab==='reports'&&<Reports hist={hist}/>}{tab==='device'&&<><DevicePanel th={th} setTh={setTh} cal={cal} setCal={setCal} rd={rd} dev={dev} handle={bh.current}/><Validation cal={cal} setCal={setCal}/></>}</main>
  <nav>{['live','hydration','ai','history','reports','team','device','profile'].map(x=><a key={x} className={tab===x?'on':''} onClick={()=>setTab(x)}>{x}</a>)}</nav></div>}
