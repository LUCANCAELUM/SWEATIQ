export const apiUrl=()=>localStorage.getItem('hs_api')||(import.meta as any).env?.VITE_API_URL||''
const tok=()=>localStorage.getItem('hs_tok')
export async function auth(path:'register'|'login',email:string,password:string,name=''){
  const r=await fetch(apiUrl()+'/auth/'+path,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email,password,name})})
  if(!r.ok)throw new Error(await r.text());const j=await r.json();localStorage.setItem('hs_tok',j.token);return j}
export async function sync():Promise<number>{
  const q=JSON.parse(localStorage.getItem('hs_q')||'[]');if(!apiUrl()||!tok()||!q.length)return 0
  try{const r=await fetch(apiUrl()+'/sessions/bulk',{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+tok()},body:JSON.stringify(q)})
    if(r.ok){localStorage.setItem('hs_q','[]');return q.length}}catch{}return 0}
export const enqueue=(s:any)=>{const q=JSON.parse(localStorage.getItem('hs_q')||'[]');q.push(s);localStorage.setItem('hs_q',JSON.stringify(q));return sync()}
export const queued=()=>JSON.parse(localStorage.getItem('hs_q')||'[]').length
