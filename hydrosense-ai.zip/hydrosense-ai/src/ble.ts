import {PROFILE,decodeSweat,Sample} from './sensorProfile'
export type Handle={write:(chr:string,b:Uint8Array)=>Promise<void>;disconnect:()=>void}
const isNative=()=>!!(window as any).Capacitor?.isNativePlatform?.()
const hrv=(v:DataView)=>v.getUint8(0)&1?v.getUint16(1,true):v.getUint8(1)
export async function connectSensor(cb:{onSample:(s:Sample)=>void;onHr:(n:number)=>void;onState:(s:string)=>void}):Promise<Handle>{
  const dec=(v:DataView)=>{const s=decodeSweat(new Uint8Array(v.buffer,v.byteOffset,v.byteLength));if(s)cb.onSample(s)}
  if(isNative()){
    const {BleClient}=await import('@capacitor-community/bluetooth-le');await BleClient.initialize()
    const d=await BleClient.requestDevice({services:[PROFILE.service],optionalServices:[PROFILE.hrService]})
    await BleClient.connect(d.deviceId,()=>cb.onState('Sensor connection interrupted'))
    await BleClient.startNotifications(d.deviceId,PROFILE.service,PROFILE.data,dec)
    try{await BleClient.startNotifications(d.deviceId,PROFILE.hrService,PROFILE.hrChar,v=>cb.onHr(hrv(v)))}catch{}
    cb.onState('Sensor connected')
    return{write:(c,b)=>BleClient.write(d.deviceId,PROFILE.service,c,new DataView(b.buffer,b.byteOffset,b.byteLength)),disconnect:()=>{BleClient.disconnect(d.deviceId)}}}
  const nav:any=navigator;if(!nav.bluetooth)throw new Error('Web Bluetooth unsupported. Use Chrome or the Android app.')
  const d=await nav.bluetooth.requestDevice({filters:[{services:[PROFILE.service]}],optionalServices:[PROFILE.hrService]})
  d.addEventListener('gattserverdisconnected',()=>cb.onState('Sensor connection interrupted'))
  const g=await d.gatt.connect(),sv=await g.getPrimaryService(PROFILE.service),c=await sv.getCharacteristic(PROFILE.data)
  await c.startNotifications();c.addEventListener('characteristicvaluechanged',(e:any)=>dec(e.target.value))
  try{const h=await (await g.getPrimaryService(PROFILE.hrService)).getCharacteristic(PROFILE.hrChar);await h.startNotifications();h.addEventListener('characteristicvaluechanged',(e:any)=>cb.onHr(hrv(e.target.value)))}catch{}
  cb.onState('Sensor connected')
  return{write:async(chr,b)=>{await (await sv.getCharacteristic(chr)).writeValue(b)},disconnect:()=>g.disconnect()}}
