import {useEffect,useRef,useState} from 'react'
import {Reading,Prof,simulate,assess,sodiumMgH} from './engine'
import {auth,sync,queued,apiUrl} from './api'
import {flash} from './firmware'
const COL:any={GREEN:'#39ff88',YELLOW:'#ffd23f',ORANGE:'#ff8a2b',RED:'#ff3b4e'}
export const Splash=({children}:any)=>{const [s,set]=useState(true);useEffect(()=>{const id=setTimeout(()=>set(false),1400);return()=>clearTimeout(id)},[])
  return s?<div className="splash"><h1>HYDROSENSE <span>AI</span></h1><p>Sweat science, live.</p></div>:children}
export type Th={skin:number;rate:number;deficit:number;na:number;voice:boolean}
export const DEF_TH:Th={skin:37,rate:1500,deficit:500,na:1200,voice:true}
const say=(m:string,u:boolean)=>{if(u&&navigator.vibrate)navigator.vibrate([300,100,300]);try{speechSynthesis.cancel();speechSynthesis.speak(new SpeechSynthesisUtterance((u?'Warning. ':'')+m))}catch{}}
export function useAlerts(A:any,r:Reading|null,th:Th,intake:number){
  const last=useRef<any>({});const [msg,setMsg]=useState<{t:string;u:boolean}|null>(null)
  useEffect(()=>{if(!r||!A)return;const c:[string,string,boolean][]=[]
    if(A.level==='RED')c.push(['red','Stop and seek help. High-risk readings.',true])
    if(r.skin!=null&&r.skin>=th.skin)c.push(['skin','Your skin temperature is rising.',false])
    if(r.rate!=null&&r.rate>=th.rate)c.push(['rate','Your sweat rate is increasing.',false])
    if(A.deficit>=th.deficit)c.push(['def','Your estimated fluid deficit is increasing. Hydration check recommended.',false])
    const na=sodiumMgH(r);if(na!=null&&na>=th.na)c.push(['na','Your estimated sodium loss is elevated.',false])
    for(const [k,m,u] of c)if(Date.now()-(last.current[k]||0)>(u?20000:90000)){last.current[k]=Date.now();setMsg({t:m,u});if(th.voice)say(m,u);break}
  },[r?.t]);return msg}
const hav=(a:any,b:any)=>{const R=6371e3,q=Math.PI/180,x=(b.latitude-a.latitude)*q,y=(b.longitude-a.longitude)*q
  const h=Math.sin(x/2)**2+Math.cos(a.latitude*q)*Math.cos(b.latitude*q)*Math.sin(y/2)**2;return 2*R*Math.asin(Math.sqrt(h))}
export function useGps(on:boolean){const [d,setD]=useState(0);const p=useRef<any>(null)
  useEffect(()=>{if(!on||!navigator.geolocation)return;setD(0);p.current=null
    const id=navigator.geolocation.watchPosition(g=>{const n=g.coords;if(p.current&&n.accuracy<50)setD(x=>x+hav(p.current,n));p.current=n},()=>{},{enableHighAccuracy:true})
    return()=>navigator.geolocation.clearWatch(id)},[on]);return d}
const wsUrl=(room:string)=>apiUrl().replace(/^http/,'ws')+'/ws/'+encodeURIComponent(room)+'?token='+encodeURIComponent(localStorage.getItem('hs_tok')||'')
export function usePublish(r:Reading|null,A:any,name:string,intake:number){
  const ws=useRef<WebSocket|null>(null),room=localStorage.getItem('hs_room')||''
  useEffect(()=>{if(!room||!apiUrl()||!localStorage.getItem('hs_tok'))return;const w=new WebSocket(wsUrl(room));ws.current=w;return()=>w.close()},[])
  useEffect(()=>{if(r&&A&&ws.current?.readyState===1)ws.current.send(JSON.stringify({n:name||'Athlete',level:A.level,rate:r.rate,loss:r.loss,intake,sim:r.sim,ts:Date.now()}))},[r?.t])}
export async function exportPdf(hist:any[]){const {jsPDF}=await import('jspdf');const d=new jsPDF();d.setFontSize(16);d.text('HydroSense AI - Session report',14,16);d.setFontSize(9)
  d.text('Estimates only; not medical advice. Simulated sessions are marked.',14,22);let y=32
  hist.slice(0,40).forEach(s=>{if(y>275){d.addPage();y=16}d.text(new Date(s.date).toLocaleString()+(s.sim?' [SIMULATED]':''),14,y)
    d.text(`${Math.round(s.dur/60)} min | loss ${Math.round(s.loss)} mL | intake ${Math.round(s.intake)} mL | Na ${Math.round(s.naMg)} mg | peak ${s.risk}`,14,y+5);y+=13});d.save('hydrosense-report.pdf')}
export function Validation({cal,setCal}:any){
  const [rows,setRows]=useState<number[][]>(()=>{try{return JSON.parse(localStorage.getItem('hs_val')||'[]')}catch{return[]}}),[a,setA]=useState(''),[b,setB]=useState(''),[tol,setTol]=useState(10)
  const save=(x:number[][])=>{setRows(x);localStorage.setItem('hs_val',JSON.stringify(x))}
  const n=rows.length,d=rows.map(x=>x[0]-x[1]),bias=n?d.reduce((p,q)=>p+q,0)/n:0,sd=n>1?Math.sqrt(d.reduce((p,q)=>p+(q-bias)**2,0)/(n-1)):0
  const mape=n?rows.reduce((p,x)=>p+Math.abs(x[0]-x[1])/x[1]*100,0)/n:0,ms=rows.reduce((p,x)=>p+x[0],0)/(n||1),ml=rows.reduce((p,x)=>p+x[1],0)/(n||1)
  const cv=rows.reduce((p,x)=>p+(x[0]-ms)*(x[1]-ml),0),vs=rows.reduce((p,x)=>p+(x[0]-ms)**2,0),vl=rows.reduce((p,x)=>p+(x[1]-ml)**2,0),rc=vs&&vl?cv/Math.sqrt(vs*vl):0
  const f=n?rows.reduce((p,x)=>p+x[0]*x[1],0)/rows.reduce((p,x)=>p+x[0]**2,0):1
  return<div className="card"><h2>Lab validation (sweat sodium)</h2><small>Enter paired RAW sensor values (calibration 1.00) and lab reference values (mmol/L) from the same sweat samples. Aim for 20+ pairs across the range.</small>
    <div className="ctl"><input placeholder="Sensor" value={a} onChange={e=>setA(e.target.value)}/><input placeholder="Lab" value={b} onChange={e=>setB(e.target.value)}/><button onClick={()=>{if(+a>0&&+b>0){save([...rows,[+a,+b]]);setA('');setB('')}}}>Add</button></div>
    {n>0&&<><p>n={n} · bias {bias.toFixed(1)} mmol/L · MAPE {mape.toFixed(1)}% · r={rc.toFixed(3)} · limits of agreement {(bias-1.96*sd).toFixed(1)} to {(bias+1.96*sd).toFixed(1)} · suggested factor {f.toFixed(3)}</p>
    <label>Accept if MAPE ≤ (%)<input type="number" value={tol} onChange={e=>setTol(+e.target.value)}/></label>
    <p>{n<20?'Not enough pairs for a verdict (need 20+).':mape<=tol?`Meets your criterion (MAPE ${mape.toFixed(1)}% ≤ ${tol}%).`:'Does not meet your criterion.'} Results are only as good as your reference data.</p>
    <div className="ctl"><button onClick={()=>{setCal(+f.toFixed(3));localStorage.setItem('hs_cal',f.toFixed(3))}}>Apply factor ({cal})</button><button className="alt" onClick={()=>save([])}>Clear</button></div></>}</div>}
export function Team(){
  const [ro,setRo]=useState<any[]>(()=>{try{return JSON.parse(localStorage.getItem('hs_team')||'')}catch{return[{n:'Athlete A',mass:60,age:25},{n:'Athlete B',mass:75,age:32},{n:'Athlete C',mass:68,age:28}]}})
  const [on,setOn]=useState(false),[st,setSt]=useState<any>({}),[nm,setNm]=useState(''),[room,setRoom]=useState(localStorage.getItem('hs_room')||''),[live,setLive]=useState<any>({}),[ws,setWs]=useState('offline'),wr=useRef<WebSocket|null>(null)
  useEffect(()=>()=>wr.current?.close(),[])
  const conn=()=>{localStorage.setItem('hs_room',room);wr.current?.close();const w=new WebSocket(wsUrl(room));wr.current=w;w.onopen=()=>setWs('live');w.onclose=()=>setWs('offline');w.onmessage=e=>{try{const m=JSON.parse(e.data);setLive((x:any)=>({...x,[m.n]:m}))}catch{}}};const ref=useRef<any>({})
  useEffect(()=>{localStorage.setItem('hs_team',JSON.stringify(ro))},[ro])
  useEffect(()=>{if(!on)return;const id=setInterval(()=>{ro.forEach((a,i)=>{const p=ref.current[a.n]||{t:0,r:null,in:0};p.t+=10;p.r=simulate(p.t*(.8+i*.15),p.r,10);ref.current[a.n]=p});setSt({...ref.current})},1000);return()=>clearInterval(id)},[on,ro])
  return<div className="card"><h2>Live team (WebSocket)</h2><small>Athletes publish from their own app using the same room name (reload their app after changing it). Needs backend + login (Device tab).</small>
    <div className="ctl"><input placeholder="Room name" value={room} onChange={e=>setRoom(e.target.value)}/><button onClick={conn}>Join</button></div><small>{ws}</small>
    {Object.values(live).map((m:any)=><div className="row" key={m.n}><b>{m.n} <i style={{color:Date.now()-m.ts>15000?'#8fb3c7':COL[m.level]}}>{Date.now()-m.ts>15000?'STALE':m.level}</i>{m.sim&&<i className="sim">simulated</i>}</b><span>{Math.round(m.rate??0)} mL/h · loss {Math.round(m.loss)} mL · drank {m.intake} mL</span></div>)}
    <h2>Team monitor</h2><small>Simulated athletes for demo. Live team data needs the backend WebSocket.</small>
    <div className="ctl"><button onClick={()=>setOn(!on)}>{on?'Pause':'Start monitoring'}</button></div>
    {ro.map(a=>{const p=st[a.n];const A=p?.r?assess(p.r,p.in,{name:a.n,age:a.age,mass:a.mass,sport:'',level:''} as Prof):null
      return<div className="row" key={a.n}><b>{a.n} <i style={{color:A?COL[A.level]:'#8fb3c7'}}>{A?.level||'idle'}</i></b>
      <span>{p?.r?`${Math.round(p.r.rate)} mL/h · loss ${Math.round(p.r.loss)} mL · drank ${p.in} mL`:`${a.mass} kg`}</span>
      {p?.r&&<button className="alt" onClick={()=>{ref.current[a.n].in+=100;setSt({...ref.current})}}>+100 mL</button>}</div>})}
    <div className="ctl"><input placeholder="Add athlete" value={nm} onChange={e=>setNm(e.target.value)}/><button onClick={()=>{if(nm){setRo([...ro,{n:nm,mass:70,age:30}]);setNm('')}}}>Add</button></div></div>}
export function Reports({hist}:{hist:any[]}){
  const [p,setP]=useState('week')
  const key=(d:string)=>{const x=new Date(d);if(p==='year')return''+x.getFullYear();if(p==='month')return x.toISOString().slice(0,7);const s=new Date(x);s.setDate(x.getDate()-x.getDay());return s.toISOString().slice(0,10)}
  const g:any={};hist.forEach(s=>{const k=key(s.date);const o=g[k]=g[k]||{n:0,dur:0,loss:0,na:0,i:0};o.n++;o.dur+=s.dur;o.loss+=s.loss;o.na+=s.naMg;o.i+=s.intake})
  return<div className="card"><h2>Performance reports</h2><div className="ctl">{['week','month','year'].map(x=><button key={x} className={p===x?'':'alt'} onClick={()=>setP(x)}>{x}</button>)}</div>
    {!hist.length&&<p>No saved sessions yet.</p>}
    {Object.keys(g).sort().reverse().map(k=>{const o=g[k];return<div className="row" key={k}><b>{k}</b><span>{o.n} sessions · {Math.round(o.dur/60)} min · loss {Math.round(o.loss)} mL · drank {Math.round(o.i)} mL · Na {Math.round(o.na)} mg</span></div>})}
    {!!hist.length&&<button className="alt" onClick={()=>exportPdf(hist)}>Export PDF</button>}</div>}
export function DevicePanel({th,setTh,cal,setCal,rd,dev,handle}:any){
  const [fp,setFp]=useState(''),[e,setE]=useState(''),[pw,setPw]=useState(''),[u,setU]=useState(apiUrl()),[m,setM]=useState('')
  const q=rd.slice(-20).filter((r:any)=>r.rate!=null).length,qual=rd.length?Math.round(q/Math.min(20,rd.length)*100):null
  const num=(k:keyof Th)=><label key={k}>{k}<input type="number" value={th[k] as number} onChange={x=>{const t={...th,[k]:+x.target.value};setTh(t);localStorage.setItem('hs_th',JSON.stringify(t))}}/></label>
  return<div className="card"><h2>Device & alerts</h2><p>{dev}. Signal quality: {qual==null?'no data':qual+'%'}. Firmware: simulator v0.1 (real devices update through the vendor's DFU tool).</p>
    <label>Sodium calibration factor (from lab reference)<input type="number" step="0.01" value={cal} onChange={x=>{setCal(+x.target.value);localStorage.setItem('hs_cal',x.target.value)}}/></label>
    <h2>Alert thresholds</h2>{(['skin','rate','deficit','na'] as const).map(num)}
    <label>voice alerts<input type="checkbox" checked={th.voice} onChange={x=>{const t={...th,voice:x.target.checked};setTh(t);localStorage.setItem('hs_th',JSON.stringify(t))}}/></label>
    <h2>Firmware update</h2><input type="file" accept=".bin" onChange={async x=>{const f=x.target.files?.[0];if(!f)return;if(!handle)return setFp('Connect the sensor first.');if(!confirm(`Flash ${f.name} (${f.size} bytes)? Keep the device charged and nearby.`))return
      try{await flash(new Uint8Array(await f.arrayBuffer()),handle.write,p=>setFp(`Uploading ${Math.round(p*100)}%`));setFp('Upload complete. Device verifies CRC32 and reboots.')}catch(er:any){setFp('Failed: '+er.message)}}}/><small>{fp}</small>
    <h2>Cloud sync</h2><input placeholder="Backend URL" value={u} onChange={x=>setU(x.target.value)} onBlur={()=>localStorage.setItem('hs_api',u)}/>
    <input placeholder="Email" value={e} onChange={x=>setE(x.target.value)}/><input type="password" placeholder="Password" value={pw} onChange={x=>setPw(x.target.value)}/>
    <div className="ctl"><button onClick={()=>{localStorage.setItem('hs_api',u);auth('login',e,pw).then(()=>setM('Logged in'),x=>setM(String(x.message||x)))}}>Log in</button>
    <button className="alt" onClick={()=>{localStorage.setItem('hs_api',u);auth('register',e,pw).then(()=>setM('Registered'),x=>setM(String(x.message||x)))}}>Register</button>
    <button className="alt" onClick={()=>sync().then(n=>setM(`Synced ${n}`))}>Sync ({queued()})</button></div><small>{m}</small></div>}
