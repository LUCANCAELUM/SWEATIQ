import {PROFILE} from './sensorProfile'
export const crc32=(b:Uint8Array)=>{let c=~0;for(const x of b){c^=x;for(let i=0;i<8;i++)c=c&1?(c>>>1)^0xedb88320:c>>>1}return(~c)>>>0}
// Protocol (your firmware must implement it): control<-[0x01,len u32,crc32 u32]; data<-[seq u16,<=128 B] x N; control<-[0x02]; device verifies CRC32, then reboots.
export async function flash(fw:Uint8Array,write:(chr:string,b:Uint8Array)=>Promise<void>,onP:(p:number)=>void){
  const CH=128,h=new DataView(new ArrayBuffer(9));h.setUint8(0,1);h.setUint32(1,fw.length,true);h.setUint32(5,crc32(fw),true)
  await write(PROFILE.fwControl,new Uint8Array(h.buffer))
  for(let o=0,i=0;o<fw.length;o+=CH,i++){const c=fw.subarray(o,o+CH),p=new Uint8Array(2+c.length);new DataView(p.buffer).setUint16(0,i&0xffff,true);p.set(c,2);await write(PROFILE.fwData,p);onP(Math.min(1,(o+CH)/fw.length))}
  await write(PROFILE.fwControl,new Uint8Array([2]))}
