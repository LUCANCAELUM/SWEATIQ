import {createRoot} from 'react-dom/client'
import App from './App'
import {Splash} from './extras'
import {sync} from './api'
import './styles.css'
createRoot(document.getElementById('root')!).render(<Splash><App/></Splash>)
window.addEventListener('online',()=>sync())
if('serviceWorker' in navigator)navigator.serviceWorker.register('./sw.js').catch(()=>{})
